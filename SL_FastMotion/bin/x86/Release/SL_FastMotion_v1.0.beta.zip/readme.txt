Copyright (C) 2014 Santiago Villafuerte <san.link@yahoo.com.mx>
http://www.migsantiago.com

Liberado con GNU GPL, ver detalles al final.

SL FastMotion - Un programa que crea videos
en c�mara r�pida a partir de una c�mara web
o del escritorio de Windows.

Basado en:
WebCamLib.dll - Source?
MEncoder.exe - http://www.mplayerhq.hu/design7/dload.html

El uso de este software es bajo �nica
responsabilidad del usuario final.

SL FastMotion - A program that creates Time Lapse videos from your webcam or your Windows desktop.
Copyright (C) 2014 Santiago Villafuerte <san.link@yahoo.com.mx>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.